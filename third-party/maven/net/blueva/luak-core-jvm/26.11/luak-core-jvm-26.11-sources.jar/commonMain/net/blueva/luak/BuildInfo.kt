package net.blueva.luak

internal object BuildInfo {
    const val VERSION: String = "Luak 26.11"
}
